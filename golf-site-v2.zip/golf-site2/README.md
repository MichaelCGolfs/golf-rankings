# The Card — Golf Rankings

Single-file site with all 80 courses from your spreadsheet. Click any row to open the full course page.

## Deploy to GitHub Pages (10 min)

1. Go to **github.com** → sign in or create a free account
2. Click **+** → **New repository** → name it `golf-rankings` → set to **Public** → Create
3. Click **uploading an existing file** → drag in `index.html` → Commit
4. Go to **Settings → Pages** → under Branch select `main` → Save
5. Live in ~2 min at: `https://YOUR-USERNAME.github.io/golf-rankings/`

---

## Adding Written Reviews

In `index.html`, find the `REVIEWS` object near the top of the `<script>` tag. Add any course by its exact name:

```js
const REVIEWS = {
  "Coyote Ridge": `<p>Your review text here...</p><p>Second paragraph...</p>`,
  "Pine Dunes": `<p>Another review...</p>`,
  // add more...
};
```

The course name must match exactly what's in the data (same capitalization, punctuation).

---

## Adding Photos

In the `REVIEWS` object, add a `photos` array alongside the review. Then update the modal body section to render them — or simply link them in the review text:

```js
"Old American Golf Club": `
  <p>Your review text here...</p>
  <img src="https://your-image-url.com/photo.jpg" style="width:100%;margin:1rem 0;">
`,
```

**Easy photo hosting:**
- Upload to your GitHub repo under `images/` folder → reference as `images/photo.jpg`
- Upload to Google Photos → right-click image → Copy image address
- Upload to Imgur.com → get direct link

---

## Updating Scores

All scores are pulled directly from your CSV. To update:
1. Edit your spreadsheet
2. Re-export as CSV
3. Re-run the build script (or ask Claude to rebuild with the new CSV)

---

## Keyboard Shortcuts (on the site)

- `Escape` — close course detail
- `→ / ←` arrow keys — navigate between courses while detail is open
